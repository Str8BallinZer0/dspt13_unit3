from setuptools import find_packages, setup

setup(name='dspt13derekl',
      version='0.1',
      description='A foo utility',
      author='Ewen Cheslack-Postava',
      author_email='me@ewencp.org',
      platforms=['any'],  # more specific e.g. 'win32' 'cygwin' 'osx'
      license='BSD',
      url='https://github.com/ewencp/foo',
      packages=find_packages(),
      )
